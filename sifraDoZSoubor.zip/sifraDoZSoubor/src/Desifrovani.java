import javax.crypto.*;
import javax.crypto.spec.SecretKeySpec;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.util.Base64;

public class Desifrovani {

    public static void main(String[] args) throws IOException, NoSuchAlgorithmException, NoSuchPaddingException, InvalidKeyException, IllegalBlockSizeException, BadPaddingException {

        //byte[] vstupvBytes = Files.readString(Paths.get("file.txt")).getBytes();
        String vstup = Base64.getEncoder().encodeToString(Files.readString(Paths.get("file.txt");

        StringBuilder builder = new StringBuilder();
        byte[] klicVBytes = new byte[Zasifrovani.kolik[1]];

        for (int i = 0; i < Zasifrovani.kolik[0]; i++) {
            builder.append(vstup[i]);
        }

        String sifrMess = builder.toString();

        System.arraycopy(vstup, Zasifrovani.kolik[0], klicVBytes, Zasifrovani.kolik[0], Zasifrovani.kolik[1] - Zasifrovani.kolik[0]);
        SecretKey key = new SecretKeySpec(klicVBytes, 0, klicVBytes.length, "AES");

        Cipher cipher = Cipher.getInstance("AES");
        cipher.init(Cipher.DECRYPT_MODE, key);
        byte[] out = cipher.doFinal(sifrMess.getBytes());

        System.out.println(new String(out));
    }
}
