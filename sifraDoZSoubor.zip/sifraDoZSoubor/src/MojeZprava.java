import javax.crypto.SecretKey;

public class MojeZprava {
    SecretKey sk;
    byte[] bytes;

    public MojeZprava(SecretKey sk, byte[] bytes) {
        this.sk = sk;
        this.bytes = bytes;
    }
}
