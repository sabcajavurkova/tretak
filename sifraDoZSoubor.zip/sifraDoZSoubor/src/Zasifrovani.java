import javax.crypto.*;
import java.io.IOException;
import java.io.Serializable;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.util.Arrays;
import java.util.Base64;
import java.util.Scanner;

public class Zasifrovani{

    static int[] kolik = new int[2];

    public static void main(String[] args) throws NoSuchAlgorithmException, NoSuchPaddingException, InvalidKeyException, IllegalBlockSizeException, BadPaddingException, IOException {

        Scanner sc = new Scanner(System.in);
        String str = sc.nextLine();

        KeyGenerator keyGenerator = KeyGenerator.getInstance("AES");
        keyGenerator.init(128);
        SecretKey key = keyGenerator.generateKey();

        Cipher cipher = Cipher.getInstance("AES");
        cipher.init(Cipher.ENCRYPT_MODE, key);

        byte[] sifrMess = cipher.doFinal(str.getBytes());
        byte[] klic = key.getEncoded();

        byte[] preOut = new byte[sifrMess.length + klic.length];

        System.arraycopy(sifrMess, 0, preOut, 0, sifrMess.length);
        System.arraycopy(klic, 0, preOut, sifrMess.length, klic.length);

        String out = Base64.getEncoder().encodeToString(preOut);
        Files.write(Paths.get("file.txt"), out.getBytes());


        /*String out1 = Base64.getEncoder().encodeToString(sifrMess);
        Files.write(Paths.get("mess.txt"), out1.getBytes());
        String out2 = Base64.getEncoder().encodeToString(klic);
        Files.write(Paths.get("key.txt"), out2.getBytes());*/

        kolik[0] = Base64.getEncoder().encodeToString(sifrMess).length();
        kolik[1] = Base64.getEncoder().encodeToString(klic).length();

        System.out.println(kolik[0] + " " + kolik[1]);
    }
}