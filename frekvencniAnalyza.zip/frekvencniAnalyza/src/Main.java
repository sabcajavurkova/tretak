import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.HashMap;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) throws IOException {
        Scanner sc = new Scanner(System.in);
        String textovyRetezec = sc.nextLine();
        Path path = Path.of("yipe.txt");
        String ctenySoubor = Files.readString(path);

        int i = 0;
        HashMap<Character, Integer> pocetPismenek = new HashMap<>();
        for (char ch: textovyRetezec.toCharArray()) {
            if(!pocetPismenek.containsKey(ch)){
                pocetPismenek.put(ch,1);
            }else{
                pocetPismenek.replace(ch, pocetPismenek.get(ch), pocetPismenek.get(ch)+1);
            }
            i++;
        }

        System.out.println(pocetPismenek);
    }
}