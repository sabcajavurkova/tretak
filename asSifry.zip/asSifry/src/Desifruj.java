import javax.crypto.*;
import javax.crypto.spec.SecretKeySpec;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;

public class Desifruj {
    public static void main(String[] args) throws IOException, NoSuchPaddingException, NoSuchAlgorithmException, InvalidKeyException, IllegalBlockSizeException, BadPaddingException {
        byte[] message = Files.readAllBytes(Path.of("message.dat"));
        byte[] k = Files.readAllBytes(Path.of("klicPrivat.dat"));

        SecretKey key = new SecretKeySpec(k, "RSA");

        Cipher cipher = Cipher.getInstance("RSA");
        cipher.init(Cipher.PRIVATE_KEY, key);
        byte[] out = cipher.doFinal(message);

        System.out.println(new String(out));
    }
}