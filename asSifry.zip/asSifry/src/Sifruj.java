import javax.crypto.*;
import javax.crypto.spec.SecretKeySpec;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.util.Scanner;

public class Sifruj {
    public static void main(String[] args) throws NoSuchPaddingException, NoSuchAlgorithmException, InvalidKeyException, IllegalBlockSizeException, BadPaddingException, IOException {
        Scanner sc = new Scanner(System.in);

        String str = sc.nextLine();

        Path jmenoSouboru = Paths.get("klicPublic.dat");
        byte[] k = Files.readAllBytes(jmenoSouboru);

        SecretKey key = new SecretKeySpec(k, "RSA");

        Cipher cipher = Cipher.getInstance("RSA");
        cipher.init(Cipher.PUBLIC_KEY, key);
        byte[] out = cipher.doFinal(str.getBytes());

        Path jmenoSouboru1 = Paths.get("message.dat");
        Files.write(jmenoSouboru1, out);
    }
}