import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.security.*;
import java.util.Base64;

public class GenerujKlic {
    public static void main(String[] args) throws NoSuchAlgorithmException, IOException {
        KeyPairGenerator keyPairGenerator = KeyPairGenerator.getInstance("RSA");
        keyPairGenerator.initialize(512);
        KeyPair keyPair = keyPairGenerator.generateKeyPair();

        Files.write(Path.of("klicPrivate.dat"), keyPair.getPrivate().getEncoded());

        PublicKey publicKey = keyPair.getPublic();
        Path fn1 = Path.of("klicPublic.dat");
        byte[] out = publicKey.getEncoded();
        Files.write(fn1, out);

        String encodedString = Base64.getEncoder().encodeToString(out);
        byte[] decodedString = Base64.getDecoder().decode(encodedString);

        System.out.println(encodedString);
    }
}