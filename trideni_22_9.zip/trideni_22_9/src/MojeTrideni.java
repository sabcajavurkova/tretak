import java.lang.reflect.Array;
import java.util.Arrays;

public class MojeTrideni {

    public static void main(String[] args) {

        Clovek[] arr = new Clovek[]{
                new Clovek("Sabina","Javurkova", 2005),
                new Clovek("Evzen","Houzvicka", 1995),
                new Clovek("Flint","Kokrspanel", 2003),
                new Clovek("Jara","Cimrman", 1800),
                new Clovek("Josef","Svejk", 1891),
                new Clovek("Mariia","Gavrylenko", 2006),
                new Clovek("Jan","Komensky", 1592),
                new Clovek("Fuska","Poulicni", 2014),
                new Clovek("Praotec","Cech", 644),
                new Clovek("Hafik","Malinky", 2019)
        };


        for (int i = 0; i < arr.length-1; i++) {

            Clovek pomocnaPromena;

            if(arr[i+1].getRokNarozeni() < arr[i].getRokNarozeni()){
                pomocnaPromena = arr[i+1];
                arr[i+1] = arr[i];
                arr[i] = pomocnaPromena;
            }

        }

        System.out.println(Arrays.toString(arr));

    }


    // bubble sort - služka Bard

    /*public void prohod(Clovek c1, Clovek c2){
        Clovek pomocnaPromena;
    }*/

}