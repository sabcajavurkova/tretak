public class Main {

    public static void sort(int[] pole){
        boolean rozhazeny = true;
        while(rozhazeny){
            rozhazeny =false;
            for (int i = 1; i < pole.length; i++) {
                if(pole[i-1]>pole[i]){
                    rozhazeny =true;
                    int pomocnaPromena=pole[i-1];
                    pole[i-1]=pole[i];
                    pole[i]=pomocnaPromena;
                }
            }
        }
    }
    public static void main(String[] args) {
        int[] pole = {13,5,8,123,1,2};
        sort(pole);
        for (int p:pole) {
            System.out.println(p);
        }
    }
}