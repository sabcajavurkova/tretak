public class metodaSort {
    void sort(int[] pole){
        for (int i = 0; i < pole.length; i++) {
            int pomocnaPromena;
            if(pole[i+1]>pole[i]){
                pomocnaPromena=pole[i+1];
                pole[i+1]=pole[i];
                pole[i]=pomocnaPromena;
            }
        }
    }
}
