import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        // char[] abeceda = {'a', 'b','c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's','t', 'u', 'v', 'w', 'x', 'y', 'z'};

        int indexPosunuti = sc.nextInt();
        String retezec = sc.next(); // načte jedno slovo bez háčků a čárek
        char[] pismenka = new char[retezec.length()];

        for (int i = 0; i < retezec.length(); i++) {
            pismenka[i] = retezec.charAt(i);
        }

        char[] pismenka2 = new char[retezec.length()];

        // šifrace
        for (int i = 0; i < retezec.length(); i++) {

            int y = (int)pismenka[i];
            int j = y + indexPosunuti;

            if (j > 122){
                j -= 26; // dám na začátek abecedy
            }

            char p2 = (char)j;
            pismenka2[i] = p2;

            //System.out.println(i + " : " + j + " - " + p + " : " + p2);
            System.out.print(p2);

        }

        System.out.println();

        // dešifrace
        for (int i = 0; i < retezec.length(); i++) {
            int y = (int) pismenka2[i];
            int j = y - indexPosunuti;

            if (j > 'a'){
                j -= 26; // dám na začátek abecedy
            }
            if (j < 'a'){
                j += 26; // dám na začátek abecedy
            }

            char p3 = (char)j;

            //System.out.println(i + " : " + j + " - " + p + " : " + p2);
            System.out.print(p3);
        }

    }
}