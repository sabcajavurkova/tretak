import java.util.Objects;
import java.util.Scanner;

public class Main {
    
    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        String sifra = sc.next();
        String odpoved;
        int finalniIndex;

        for (int i = 0;; i++) {
            System.out.println("Existuje slovo?(A/N): " + desifruj(sifra, i));
            odpoved = sc.next();
            if(Objects.equals(odpoved, "A")){
                finalniIndex = i;
                break;
            }
        }

        System.out.print("Index posunutí byl: " + finalniIndex);
    }
    
    public static String desifruj(String sifra, int indexPosunuti){
        
        char[] pismenka = new char[sifra.length()];
        for (int i = 0; i < sifra.length(); i++) {
            pismenka[i] = sifra.charAt(i);
        }

        StringBuilder slovo = new StringBuilder();
        for (int i = 0; i < sifra.length(); i++) {
            int y = (int) pismenka[i];
            int j = y - indexPosunuti;

            if (j > 'a'){
                j -= 26; // dám na začátek abecedy
            }
            if (j < 'a'){
                j += 26; // dám na začátek abecedy
            }

            char p = (char)j;

            slovo.append(p);
        }
        
        return slovo.toString();
    }
}